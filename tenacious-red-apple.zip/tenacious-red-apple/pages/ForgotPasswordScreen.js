// src/screens/ForgotPasswordScreen.js
import React, { useState } from "react";
import { View, Text, TextInput, Button, StyleSheet } from "react-native";
import { supabase} from '../config/supabase'

export default function ForgotPasswordScreen() {
  const [email, setEmail] = useState("");
  const [resetError, setResetError] = useState(null);
  const [resetSuccess, setResetSuccess] = useState(null);

  const handlePasswordReset = async () => {
    const { error } = await supabase.auth.resetPasswordForEmail(email);
    if (error) {
      setResetError(error.message);
      setResetSuccess(null);
    } else {
      setResetError(null);
      setResetSuccess("Email de recuperação enviado com sucesso!");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Recuperar Senha</Text>
      {resetError && <Text style={styles.error}>{resetError}</Text>}
      {resetSuccess && <Text style={styles.success}>{resetSuccess}</Text>}
      <TextInput
        style={styles.input}
        placeholder="Digite seu email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
      />
      <Button title="Enviar email de recuperação" onPress={handlePasswordReset} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", padding: 16 },
  title: { fontSize: 24, marginBottom: 16 },
  error: { color: "red", marginBottom: 10 },
  success: { color: "green", marginBottom: 10 },
  input: { borderWidth: 1, padding: 8, marginBottom: 16 },
});
